package com.fleet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FleetApplicationTests {

	@Test
	void contextLoads() {
	}

}
